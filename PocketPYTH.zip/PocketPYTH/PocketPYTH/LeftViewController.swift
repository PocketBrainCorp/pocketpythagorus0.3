//
//  LeftViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class LeftViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func goToCalc(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is CalcViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
